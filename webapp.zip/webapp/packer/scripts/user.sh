#!/bin/bash

# add user
sudo useradd -s /usr/sbin/nologin -d /home/csye6225 csye6225