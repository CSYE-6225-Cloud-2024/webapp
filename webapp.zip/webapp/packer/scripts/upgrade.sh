#!/bin/bash

# Upgrade
sudo dnf upgrade -y