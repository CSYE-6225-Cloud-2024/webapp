import winston from 'winston'
const { combine, timestamp } = winston.format

const logLevel = {
  fatal: 0,
  error: 1,
  warn: 2,
  info: 3,
  http: 4,
  debug: 5,
}

const logger = winston.createLogger({
  levels: logLevel,
  format: combine(timestamp(), winston.format.json()),
})

if (process.env.NODE_ENV === 'production') {
  logger.add(
    new winston.transports.File({
      filename: '/var/log/webapp/webapp.log',
      level: 'info',
    })
  )
} else {
  logger.add(
    new winston.transports.Console({
      level: 'debug',
    })
  )
}

export default logger
